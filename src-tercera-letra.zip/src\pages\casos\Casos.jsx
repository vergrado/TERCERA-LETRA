// ============================================================
// Casos.jsx
// ------------------------------------------------------------
// Página principal del módulo de Casos.
//
// Plataforma:
// TERCERA LETRA
// ============================================================
import { Button } from "react-bootstrap";
import { FaPlus } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import CasesHeader from "../../components/casos/CasesHeader";
import CasesContainer from "../../components/casos/CasesContainer";
import "../../styles/cases/cases.css";
const Casos = () => {
    //----------------------------------------------------------
    // Navegación
    //----------------------------------------------------------
    const navigate = useNavigate();
    //----------------------------------------------------------
    return (
        <div className="cases-page">
            <CasesHeader />
            <div className="d-flex justify-content-between align-items-center mb-4">
                <h2 className="mb-0">
                    Gestión de Casos
                </h2>
                <Button
                    variant="primary"
                    onClick={() => navigate("/casos/nuevo")}
                >
                    <FaPlus className="me-2"/>
                    Nuevo Caso
                </Button>
            </div>
            <CasesContainer />
        </div>
    );
};
export default Casos;